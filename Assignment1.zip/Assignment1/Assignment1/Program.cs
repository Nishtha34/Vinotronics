﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(string.Format("Newegg Marketplace API - Get Order Information at:{0}", DateTime.Now.ToString()));
            Console.WriteLine("");
            Console.WriteLine("*********************************************************************");
            Console.WriteLine("");
            try
            {
                NeweggAPIResponse orderInfoList;
                string endpoint = @"https://api.newegg.com/marketplace/ordermgmt/order/orderinfo?sellerid=A006&version=307";
               
                //Create an HttpWebRequest
                System.Net.HttpWebRequest request =
                    System.Net.WebRequest.Create(endpoint) as HttpWebRequest;

                //Remove proxy
                request.Proxy = null;
                //Specify the request method
                request.Method = "PUT";
                //Specify the xml/Json request and response content types.
                request.ContentType = "application/xml";
                request.Accept = "application/xml";
                //Attach authorization information
                request.Headers.Add("Authorization", "720ddc067f4d115bd544aff46bc75634");
                request.Headers.Add("Secretkey", "21EC2020-3AEA-1069-A2DD-08002B30309D");
                
                //Construct the query criteria in the request body
               
                //Construct the query criteria in the request body
                string requestBody = @"
  <NeweggAPIRequest>
    <OperationType>GetOrderInfoRequest</OperationType>
    <RequestBody>
        <PageIndex>1</PageIndex>
        <PageSize>10</PageSize>
        <RequestCriteria>
            <OrderNumberList>
                <OrderNumber>159243598</OrderNumber>
                <OrderNumber>41473642</OrderNumber>
            </OrderNumberList>
            <SellerOrderNumberList>
                <SellerOrderNumber>SO159243598</SellerOrderNumber>
                <SellerOrderNumber>SO41473642</SellerOrderNumber>
            </SellerOrderNumberList>
            <Status>1</Status>
            <Type>1</Type>
            <OrderDateFrom>2011-01-01 09:30:47</OrderDateFrom>
            <OrderDateTo>2011-12-17 09:30:47</OrderDateTo>
            <OrderDownloaded>0</OrderDownloaded>
            <CountryCode>USA</CountryCode>
            <PremierOrder>1</PremierOrder>
        </RequestCriteria>
    </RequestBody>
</NeweggAPIRequest>";
                byte[] byteStr = Encoding.UTF8.GetBytes(requestBody);
                request.ContentLength = byteStr.Length;
                using (Stream stream = request.GetRequestStream())
                {
                    stream.Write(byteStr, 0, byteStr.Length);
                }

                //Parse the response
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        Console.WriteLine(String.Format("Code:{0}.Error:{1}",
                            response.StatusCode.ToString(), response.StatusDescription));
                        return;
                    }
                    using (Stream responseStream = response.GetResponseStream())
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof(NeweggAPIResponse));
                        orderInfoList = serializer.Deserialize(responseStream) as NeweggAPIResponse;
                    }
                }
                string sellerID = orderInfoList.SellerID;
                string message = string.Empty;
                if (orderInfoList.ResponseBody != null)
                {
                    if(orderInfoList.ResponseBody.OrderInfoList != null)
                    {
                        if(orderInfoList.ResponseBody.OrderInfoList.OrderInfo != null)
                        {
                            long OrderNumber = orderInfoList.ResponseBody.OrderInfoList.OrderInfo.OrderNumber;
                            string ShipToFirstName = orderInfoList.ResponseBody.OrderInfoList.OrderInfo.ShipToFirstName;
                            string ShipToAddress1 = orderInfoList.ResponseBody.OrderInfoList.OrderInfo.ShipToAddress1;
                            long ShipToZipCode = orderInfoList.ResponseBody.OrderInfoList.OrderInfo.ShipToZipCode;
                            string ShipToCountryCode = orderInfoList.ResponseBody.OrderInfoList.OrderInfo.ShipToCountryCode;

                            message = String.Format("SellerID:{0} OrderNumber:{1} ShipToFirstName:{2} \r\n ShipToAddress1:{3} ShipToZipCode:{4} ShipToCountryCode:{5}",
                            sellerID,
                            OrderNumber,
                            ShipToFirstName,
                            ShipToAddress1,
                            ShipToZipCode,
                            ShipToCountryCode);
                        }   
                    }
                }
                Console.WriteLine("Response : " + message);
                Console.WriteLine("Success : " + orderInfoList.IsSuccess);
            }
            catch(WebException we)
            {
                if (((WebException)we).Status == WebExceptionStatus.ProtocolError)
                {
                    WebResponse errResp = ((WebException)we).Response;
                    using (Stream respStream = errResp.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(respStream);
                        Console.WriteLine(String.Format("{0}", reader.ReadToEnd()));
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
            Console.WriteLine("");
            Console.WriteLine("*********************************************************************");
            Console.WriteLine("");
            Console.WriteLine("Please input any key to exit……");
            Console.ReadLine();
        }
    }
    public class NeweggAPIResponse
    {
        public bool IsSuccess { get; set; }
        public string SellerID { get; set; }
        public ResponseBody ResponseBody { get; set; }
    }
    public class ResponseBody
    {
        public OrderInfoList OrderInfoList { get; set; }
    }
    public class OrderInfoList
    {
        public OrderInfo OrderInfo { get; set; }
    }

    public class OrderInfo
    {
        public long OrderNumber { get; set; }
        public string ShipToFirstName { get; set; }

        public string ShipToAddress1 { get; set; }

        public long ShipToZipCode { get; set; }

        public string ShipToCountryCode { get; set; }
    }
}
